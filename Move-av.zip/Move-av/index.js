const robot = require("robotjs");

// Function to move the mouse cursor to a random position on the screen
function moveMouse() {
    console.log('Hyperlocology Connecting....DB connection Establishing...')
    const screenSize = robot.getScreenSize();
    const randomX = Math.floor(Math.random() * screenSize.width);
    const randomY = Math.floor(Math.random() * screenSize.height);
    robot.moveMouse(randomX, randomY);
}

// Initialize last mouse movement time
let lastMouseMoveTime = Date.now();

// Function to check idle time and move the mouse if necessary
function checkIdleTime() {
    const currentTime = Date.now();
    const idleTime = currentTime - lastMouseMoveTime;
    if (idleTime > 10000) {
        moveMouse();
        lastMouseMoveTime = currentTime; // Update last move time to prevent immediate consecutive movements
    }
}

// Check mouse activity every second
setInterval(checkIdleTime, 1000);

// Polling the current mouse position
let lastMouseX = robot.getMousePos().x;
let lastMouseY = robot.getMousePos().y;

setInterval(() => {
    const currentMouseX = robot.getMousePos().x;
    const currentMouseY = robot.getMousePos().y;
    if (currentMouseX !== lastMouseX || currentMouseY !== lastMouseY) {
        lastMouseMoveTime = Date.now();
        lastMouseX = currentMouseX;
        lastMouseY = currentMouseY;
    }
}, 100);
